# -*- coding: utf-8 -*-
"""
Owen Manley, 11/21/2024, Assignment #5. I mostly used the internet for this assignment because it was a lot and there was a lot that needed to take into account for. There may not be things that were gone over 
in class (like the correlation matrix). But, it was something I found and was interested to try out. I also used the "End-To-End
Machine Learning" website in moodle for assistance. Overall, it was fun slowly learning more as time went on. There are a lot of comments; I decided to keep them
because I feel like they take you through my experience while working on the assignment. 
"""
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

####################################################################################################################################
#LOAD DATASET/EXPLORE DATASET - STEP 1
 
df = pd.read_csv("Titanic-dataset.csv", header=3) #Switching the header to 3 made it so my columns are appropriately recognized.
print(df.shape) #Seeing how many rows/columns in dataset.
print(df.info()) #Using this, I can see the datatypes, non-null count, and tells me the range.

#Replacing missing ages with median values because age is saved as an object. So, it would display errors when ran.
df['Age'] = df['Age'].fillna(df['Age'].median())
df['Sex'] = df['Sex'].map({'male': 0, 'female': 1}) #This is so male and female will display as '0' or '1' so they are displayed on graphs/models.
print(df.head(51))
print(df.tail())
#I am beginning to see NaN values. I believe them to be the headers? Because the dataframe says that there are 7 other unnamed columns.
#At least, that is what  Iam picking up on (RESOLVED).
#print(df.value_counts()) 
#This doesn't really help me other than the fact that the features are displayed on the bottom rather than the top. Not sure what the 
#unnamed headers are(RESOLVED).


print(df['Age'].describe()) #This gives me certain statistics pertaining to the dataset.
print(df["Survived"].value_counts()) #This cool function gives me a count of the total different instances in a descriptive feature. 

print("\nMissing values after imputation:")
print(df.isnull().sum())  #Shows me the total sum of null values in the dataset, if there is still any.

print(df.columns.tolist()) #Shows me the columns in a list format.

####################################################################################################################################
#EXPLORING DATA USING DIFFERENT MODELS/GRAPHS

df.hist(bins=50, figsize=(20,15)) #Shows a histogram of every feature, kind of ugly, though.
plt.show()

sns.histplot(data=df, x='Age', kde=True, hue='Survived', bins=30) #Histogram of survival rate by age.
plt.title('Age Distribution')
plt.show()

sns.countplot(data=df, x='Sex', hue='Survived') #Plot graph displaying survival rate by gender.
plt.title('Survival Rate by Sex')
plt.show()

sns.countplot(data=df, x='Pclass', hue='Survived') #Displaying survival rate by passenger class.
plt.title('Survival Rate by Passenger Class')
plt.show()

correlation_matrix = df.corr()
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm') #Shows the correlation between each of the features.
plt.title('Feature Correlation')
plt.show()

####################################################################################################################################
#LOGISTIC REGRESSION MODEL - STEP 2
#Using sklearn made this a lot easier than expected.
features = ['Pclass', 'Sex', 'Age'] #Descriptive features used to train model. 
X = df[features]
y = df['Survived'] #Target feature.

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42) #Splitting into training & test sets...

model = LogisticRegression() #Calling Logistic Regression function
model.fit(X_train, y_train)

####################################################################################################################################
#INTERPRET RESULTS - STEP 3

y_pred = model.predict(X_test) #Predicting the target feature.

####################################################################################################################################
#I aquired this section from the internet. After inspection I know what it does so I didn't just copy & paste, but just wanted to mention that here.
print("\nModel Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))
print("\nConfusion Matrix:")
sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt='d', cmap='Blues', cbar=False)
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()

feature_importance = pd.DataFrame({
    'Feature': features,
    'Coefficient': model.coef_[0]
}).sort_values(by='Coefficient', ascending=False)
####################################################################################################################################

print("\nFeature Importance:") #This displays the importance of the features I used in Logistic Regression.
print(feature_importance)

print("\nInterpretation:")
print("Features with larger absolute coefficients (positive or negative) have the most influence on survival.")