# -*- coding: utf-8 -*-
"""
Owen Manley, 11/20/2024, Assignment #4. This assignment uses gradient descent to determine
oxygen being consumed by astronaughts in a 5 minute workout. I used a lot of the internet for this assingnment 
because this assingnment was pretty confusing to me.
"""

import numpy as np
import matplotlib.pyplot as plt

#INPUT DATA - STEP 1
data = np.array([
    [1, 37.99, 41, 138],
    [2, 47.34, 42, 153],
    [3, 44.38, 37, 151],
    [4, 28.17, 46, 133],
    [5, 27.07, 48, 126],
    [6, 37.85, 44, 145],
    [7, 44.72, 43, 158],
    [8, 36.42, 46, 143],
    [9, 31.21, 37, 138],
    [10, 54.85, 38, 158],
    [11, 39.84, 43, 143],
    [12, 30.83, 43, 138]
    ])

#LOAD DATA 
ID = data[:, 0]
oxy_con = data[:, 1]
age = data[:, 2]
heart_rate = data[:, 3]
m = len(oxy_con)
print("ID: ", ID, "\n", "OxyCon: ", oxy_con, "\n", "Age: ", age, "\n ", "HeartRate: ", heart_rate)

#NORMALIZE FEATURES
normed_age = (age - np.mean(age)) / np.std(age)
normed_heart_rate = (heart_rate - np.mean(heart_rate)) / np.std(heart_rate)

#COMBINE FEATURES INTO ONE MATRIX
X =  np.column_stack((np.ones(m), normed_age, normed_heart_rate)) #Combines these features so that it displayes as a 2D array instead of a 1D.
y = oxy_con #OxyCon is our target feature, so that is set to the y-axis.

#INITIALIZE PARAMETERS RANDOMLY - STEP 2
theta =  np.random.randn(3) #For the weights and bias.

#SETTING UP HYPERPARAMETERS...
learning_rate = 0.01
iterations = 1000

#COMPUTE COST FUNCTION - STEP 3 
def cost_function(x, y, theta):
    prediction = X @ theta #@ is used to perform dot production on the matrices.
    errors = prediction - y
    return np.sum(errors ** 2) / (2 * len(y)) #Returning the sum of squared errors to calculate the cost function.

#APPLY GRADIENT DESCENT ALGORITHM - STEP 4  
def gradient_descent(x, y, theta, learning_rate, iterations ):
    m = len(y)
    cost_history = []
    
    for _ in range(iterations):
        predictions = X @ theta
        errors = predictions - y
        gradients = X.T @ errors / m #The "X.T" signifies transposition in python.
        theta -= learning_rate * gradients
        cost_history.append(cost_function(X, y, theta))
    
    return theta, cost_history

#TRAIN MODEL - STEP 5
theta, cost_history = gradient_descent(X, y, theta, learning_rate, iterations)

#CALCULATE FINAL SUM OF SQUARED ERRORS - STEP 6/7
final_cost = cost_function(X, y, theta)

def prediction(age, heart_rate, theta):
    normed_age = (age - np.mean(data[:, 2])) / np.std(data[:, 2])
    normed_heart_rate = (heart_rate - np.mean(data[:, 3])) / np.std(data[:, 3])
    input_features = np.array([1,  normed_age, normed_heart_rate])
    
    return input_features @ theta

#PREDICTING OXYGEN CONSUMPTION WITH AGE 40 AND HEART RATE 130 - STEP 9
predicted_oxy_con = prediction(40, 130, theta)
    
#PLOTTING THE COST FUNCTION - STEP 8
plt.plot(range(iterations), cost_history)
plt.xlabel('Iterations')
plt.ylabel('Cost (Sum of Squared Error)')
plt.title('Cost Function Over Iterations')
plt.show()

#OUTPUTS - STEP 8
print("Final Model Parameters (weights and bias):", theta)
print("Sum of Squared Error:", final_cost)
print("Predicted oxygen consumption for age 40 and heart rate 130:", predicted_oxy_con, "mL")

#Because I am using gradient descent, the batch size in this case is all the samples in the dataset. It isn't excplicity put in; so,
#I thought to put this comment here.