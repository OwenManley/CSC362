
"""
CSC 362. Owen Manley. Final Project.
This assignment delves into an earlier assignment in the semester applying algorithms like 
logistic regression and a support vector machine. Additionally, these are built to predict whether a patient is HOA or
PD.
"""
import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# This first section is from assignment; I thought to add it here since it already cleans the dataset.
# RUNNING AND CLEANING DATA
########################################################################################################################
# LOAD DATA  
df = pd.read_csv("pd_hoa_dataset.csv", header=0)
print(df.shape)

# EXPLORE DATA
print(df.head(5))
print(df.tail(5))

print("Number of participants:", df.shape[0] //9)
print(df.iloc[660:670, :])

# MISSING DATA
print(df["duration"].value_counts()["?"])

# Replace the "?" with np.NaN
# "Inplace" modify the dataframe in place of memory.
# If inplace weren't there, there would need to be an assignment to overwrite dataframe with return copy.
df.replace("?", np.NaN, inplace=True)
# isnull returns a boolean array designating if a value is null or not.
# Sum is a method that returns the sum of all True column-wise.
print(df.isnull().sum())

df.dropna(inplace=True)
print("AFTER DROPPING:", df.isnull().sum())
print(df.shape)
df.reset_index(inplace=True, drop=True) #Resets the index so there are no jumps in the datasets/logic errors in the future.
print(df.head(2))

# DECODE TASK
# Replace 1-8 and dot with more human readable/meaningful labels.

task_decoder = {"1": "Water Plants", "2": "Fill Medication Dispenser", 
                "3": "Wash Countertop", "4": "Sweep and Dust", 
                "5": "Cook", "6": "Wash Hands", "7": "Perform TUG", 
                "8": "Perform TUG w/Questions", "dot": "Day Out Task"}
def decode_task(df):
    ser = df["task"]
    for key in task_decoder:
        ser.replace(key, task_decoder[key], inplace=True)
decode_task(df)
print(df.head(10))

# CLEAN CLASS
def clean_class(df):
    ser = df["class"].copy()
    for i in range(len(ser)):
        curr_class = str(ser.iloc[i])
        curr_class = curr_class.lower()
        if "hoa" in curr_class or "healthy" in curr_class:
            ser.iloc[i] = "HOA"
        elif "pd" in curr_class or "parkinson" in curr_class:
            ser.iloc[i] = "PD"
        else:
            print("Unrecognized status: %d, %s" %(i, curr_class) )
    df["class"] = ser
clean_class(df)
print(df.head(25))
print(df["class"].value_counts())

# Check the types of all attributes to make sure that the data frame is storing 
# each attribute(column) in the most appropriate type.
# CHECK COLUMN TYPES
for column in df.columns:
    print(column, df[column].dtype) # Print columns and datatype of each column in data frame.
# Duration is stored as an object. Which is bad because it determines the amount of time it takes to do a task (int) and 
# there were mixed typed "?".
# print(df["duration"].mean()) #Didn't compute.
# print((df["duration"].sum())) #Also didn't compute. Durations values are supposedly stored as strings.
df["duration"] = df["duration"].astype(np.int32)
print((df["duration"].sum(), df["duration"].mean(), df["duration"].std()))
# Okay, I had to do the for loop again to essentially "update" the types of each column.
# For some reason, I would run it and "duration" would still be "object". 
for column in df.columns:
    print(column, df[column].dtype)
    
# WRITE OUT THE CLEANED DATA
df.to_csv("pd_hoa_activities_cleaned.csv", index=False)
# Makes a new csv file of the new dataset.
########################################################################################################################
# LOGISTIC REGRESSION: STEP 1/2: LOAD FEATURES INTO NUMPY, PRINT FIRST FEW VALUES
df['class'] = df['class'].map({'HOA': 0, 'PD': 1}) #Changed this to 0/1 so the model can read these classifications.


# Duration and age give the numerical values for each task; so, the task itself is irrelevant.
# Setting training values...
x_train = df[['duration', 'age']].to_numpy()  
y_train = df['class'].to_numpy()             

# Displaying the first few entries of x_train and y_train...
print("First few rows of x_train:")
print(x_train[:5])

print("\nFirst few values of y_train:")
print(y_train[:20])

# Print their shapes
print(f"\nShape of x_train: {x_train.shape}")
print(f"Shape of y_train: {y_train.shape}")
########################################################################################################################
# LOGISTIC REGRESSION/PLOT DATA/STEP 3

# Multiple different grpahs from previous assignments to use here. They didn't do much of a good job in giving me information. Judging from them, I'm gonna say that age as a feature plays the biggest factor... 
df.hist(bins=50, figsize=(20,15)) #Shows a histogram/countplot of every feature, kind of ugly, though.
plt.show()

sns.histplot(data=df, x='duration', kde=True, hue='class', bins=30) 
plt.title('Class by Duration')
plt.show()

sns.histplot(data=df, x='age', kde=True, hue='class', bins=30) 
plt.title('Class by Duration')
plt.show()

sns.histplot(data=df, x='task', kde=True, hue='class', bins=30) 
plt.title('Class by Duration')
plt.show()

sns.countplot(data=df, x='duration', hue='class') 
plt.title('Class by Duration')
plt.show()

sns.countplot(data=df, x='age', hue='class')
plt.title('Class by Age')
plt.show()

sns.countplot(data=df, x='task', hue='class') 
plt.title('class by Task')
plt.show()
########################################################################################################################
# NORMALIZATION
# Normalizing the features so the logistic regression model doesn't oscillate.
def normalize_features(x):
    return (x - np.mean(x, axis=0)) / np.std(x, axis=0)

x_train_normalized = normalize_features(x_train)

# Adding biased term to normalized features here...
x_train_with_bias = np.hstack((np.ones((x_train_normalized.shape[0], 1)), x_train_normalized))

# Initializing weights (number of features + 1 for bias)...
initial_weights = np.zeros(x_train_with_bias.shape[1])

########################################################################################################################
# STEP 4: SIGMOID FUNCTION
def sigmoid(x):
  x = np.clip(x, -500, 500) # I had to implement this here because I would keep getting an error saying that the values' boundaries would be exceeded. This is to prevent it. I presune it "clips" the variable to have a max/min size for a value.
  return 1/(1+np.exp(-x))
########################################################################################################################
# STEP 5: COST FUNCTION
def cost_function(x, y, weights):
    m = len(y) #Lenght of the training data.
    predictions = sigmoid(np.dot(x, weights)) #Predictions are made by using the logistic function * dot function * input features/weight vector.
    cost = -(1 / m) * np.sum(y * np.log(predictions) + (1 - y) * np.log(1 - predictions)) # Used to calculate the error (J(w)=−m1​i=1∑m​[y(i)log(hw​(x(i)))+(1−y(i))log(1−hw​(x(i)))]).
    return cost
########################################################################################################################
# STEP 6: GRADIENT DESCENT
# Performs gradient descent here to find the local minimum of the model.
def gradient_descent(x, y, weights, alpha, iterations ):
    m = len(y)
    cost_history = [] # Tracking cost values.
    
    for i in range(iterations):
        predictions = sigmoid(np.dot(x, weights))
        gradient = (1 / m) * np.dot(x.T, (predictions - y))
        weights -= alpha * gradient
        cost = cost_function(x, y, weights)
        cost_history.append(cost)
        
        if i % 100 == 0:
            print(f"Iteration {i}: Cost {cost}")

    return weights, cost_history
########################################################################################################################
# STEP 7: FIND THE OPTIMAL PARAMETERS FOR MODEL

# Preparing data by adding bias term...
x_train_with_bias = np.hstack((np.ones((x_train.shape[0], 1)), x_train))

# Initializing weights...
initial_weights = np.zeros(x_train_with_bias.shape[1])

# Hyperparameters
learning_rate = 0.00001  # Learning rate had to be this low or the model would oscillate like crazy. Normalizing my features didn't help either; I'm not sure why it was like this.
iterations = 1000     # How many times the model performs calculations

# Running gradient descent to find optimal weights...
optimized_weights, cost_history = gradient_descent(x=x_train_with_bias, y=y_train,weights=initial_weights, alpha=learning_rate, iterations=iterations)

# Outputting optimized weights...
print("Optimized Weights:", optimized_weights)

# Plotting cost function to check convergence...
plt.plot(cost_history)
plt.xlabel('Iterations')
plt.ylabel('Cost')
plt.title('Cost Function Convergence')
plt.show()
########################################################################################################################
# STEP 8: PREDICT FUNCTION
# Used to predict which target features are which..
def predict(x, weights):
    probabilities = sigmoid(np.dot(x, weights))
    return (probabilities >= 0.5).astype(int)

# Calculating training accuracy...
y_pred_train = predict(x_train_with_bias, optimized_weights)
accuracy_train = np.mean(y_pred_train == y_train) * 100
print(f"Training Accuracy: {accuracy_train:.2f}%")
########################################################################################################################
# STEP 9: TESTING PREDICTIONS/CALCULATING ACCURACY OF MODEL
# Predicting the testing set...
def predict_test(x_test, y_test, weights):
    # Adding bias term...
   x_test_with_bias = np.hstack((np.ones((x_test.shape[0], 1)), x_test))

   # Making predictions on test set...
   y_pred_test = predict(x_test_with_bias, weights)

   # Calculate test accuracy
   accuracy_test = np.mean(y_pred_test == y_test) * 100
   print(f"Test Accuracy: {accuracy_test:.2f}%")
########################################################################################################################        
#STEP 1: IMPLEMENT SVM
#Using SVC to make a test and training set...
x_train, x_test, y_train, y_test = train_test_split(df[['duration', 'age']], df['class'], test_size=0.2, random_state=42)

scaler = StandardScaler()
x_train_scaled = scaler.fit_transform(x_train)  # Scaling training features...
x_test_scaled = scaler.transform(x_test)  # Scaling test features...

# Step 2: Initializing SVM with SVC...
svm_model = SVC(kernel='linear', random_state=42)

# Step 3: Training model..
svm_model.fit(x_train_scaled, y_train)
########################################################################################################################
#STEP 2: PREDICTION
y_pred_train_svm = svm_model.predict(x_train_scaled)
########################################################################################################################
#STEP 3: EVALUATION
train_accuracy_svm = svm_model.score(x_train_scaled, y_train)

# Print the training accuracy of the SVM model
print(f"Training Accuracy of SVM Model: {train_accuracy_svm:.2f}")