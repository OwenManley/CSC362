# -*- coding: utf-8 -*-
"""
Owen Manley/11-12/Assignment 6.
"""
import pandas as pd
import numpy as np

#READ FILE
excel_file = 'movies.xlsx'
#LOAD EXCEL SHEET
df = pd.read_excel(excel_file)

#EXPLORE COLUMNS
columns_to_display = ['Ratings','Aggregate Followers', 'Budget','Likes','Dislikes','Comments']
pd.set_option('display.max_colwidth', None)

df.replace("?", np.NaN, inplace=True)
df_specificity = df[columns_to_display].iloc[0:50]
print(df_specificity)

#FINDING CORRELATION BETWEEN RATINGS AND FOLLOWING/BUDGET. PREDICTION CORRECT - LOW.
correlation_followers = df['Ratings'].corr(df['Aggregate Followers'])
correlation_budget = df['Ratings'].corr(df['Budget'])
correlation_likes = df['Ratings'].corr(df['Likes'])
correlation_dislikes = df['Ratings'].corr(df['Dislikes'])
correlation_comments = df['Ratings'].corr(df['Comments'])

print(f"Correlation between Ratings and Aggregate Followers: {correlation_followers}")
print(f"Correlation between Ratings and Budget: {correlation_budget}")
print(f"Correlation between Ratings and Likes: {correlation_likes}")
print(f"Correlation between Ratings and Dislikes: {correlation_dislikes}")
print(f"Correlation between Ratings and Comments: {correlation_comments}")

#pd.set_option('display.width', None)
#pd.set_option('display.max_colwidth', None)
#pd.set_option('display.max_rows',None)
#pd.set_option('display.max_columns',None)

###################################################################
#GRADIENT DESCENT SECTION

#FEATURES
"""features = ['Aggregate Followers', 'Budget', 'Gross', 'Views', 'Likes', 'Dislikes', 'Comments']"""
features = ['Budget']
#TARGET FEATURE
target = 'Ratings'

#PREPARE FEATURES(X) AND TARGET FEATURE(Y) 
X = df[features].values
y = df[target].values

df = df.dropna(subset=features + [target])

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X = scaler.fit_transform(df[features].values)
y = df[target].values

"""# NORMALIZATION
X = (X - X.mean(axis=0)) / X.std(axis=0)
"""

# INITIALIZE PARAMETERS
np.random.seed(0)  # for reproducibility
W = np.random.rand(X.shape[1])  # WEIGHTS FOR EACH FEATURE
b = np.random.rand()  # BIAS
alpha = 0.001  # LEARNING RATE
n_iterations = 1000  # NUMBER OF ITERATIONS IN GRADIENT DESCENT

# GRADIENT DESCENT LOOP
for i in range(n_iterations):
    # MAKE PREDICTIONS
    y_pred = X.dot(W) + b
    
   # CALCULATE GRADIENT FOR W AND b
    error = y_pred - y
    dW = (1 / len(y)) * X.T.dot(error)
    db = (1 / len(y)) * np.sum(error)
    
    # UPDATING WEIGHTS/BIAS...
    W -= alpha * dW
    b -= alpha * db
    
    # Optionally: Print the loss every 100 iterations
    if i % 100 == 0:
        loss = (1 / len(y)) * np.sum(error ** 2)
        print(f"Iteration {i}, Loss: {loss}")

# After training, we can make predictions
y_pred_final = X.dot(W) + b
print("Final weights:", W)
print("Final bias:", b)
